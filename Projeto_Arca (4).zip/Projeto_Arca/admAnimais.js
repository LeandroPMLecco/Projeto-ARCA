let animais = JSON.parse(localStorage.getItem("animais")) || [];

function salvarAnimal() {
    let nome = document.getElementById("nome").value;
    let tipo = document.getElementById("tipo").value;
    let porte = document.getElementById("porte").value;
    let idade = document.getElementById("idade").value;
    let descricao = document.getElementById("descricao").value;
    let indice = document.getElementById("indice").value;

    if (nome === "" || tipo === "" || porte === "" || idade === "" || descricao === "") {
    alert("Preencha todos os campos");
    return;
}

    let animal = {
        nome: nome,
        tipo: tipo,
        porte: porte,
        idade: idade,
        descricao: descricao
    };

    if (indice === "") {
        animais.push(animal);
    } else {
        animais[indice] = animal;
        document.getElementById("indice").value = "";
    }

    localStorage.setItem("animais", JSON.stringify(animais));

    limparCampos();
    mostrarAnimais();
}

function mostrarAnimais() {
    let tabela = document.getElementById("tabela-animais");

    tabela.innerHTML = "";

    animais.forEach(function (animal, index) {
        tabela.innerHTML += `
            <tr>
                <td>${animal.nome}</td>
                <td>${animal.tipo}</td>
                <td>${animal.porte}</td>
                <td>${animal.idade}</td>
                <td>
                    <button class="btn-editar" onclick="editarAnimal(${index})">
                        Editar
                    </button>

                    <button class="btn-excluir" onclick="excluirAnimal(${index})">
                        Excluir
                    </button>
                </td>
            </tr>
        `;
    });
}

function editarAnimal(index) {
    document.getElementById("nome").value = animais[index].nome;
    document.getElementById("tipo").value = animais[index].tipo;
    document.getElementById("porte").value = animais[index].porte;
    document.getElementById("idade").value = animais[index].idade;
    document.getElementById("descricao").value = animais[index].descricao;
    document.getElementById("indice").value = index;
}

function excluirAnimal(index) {
    animais.splice(index, 1);
    localStorage.setItem("animais", JSON.stringify(animais));
    mostrarAnimais();
}

function limparCampos() {
    document.getElementById("nome").value = "";
    document.getElementById("idade").value = "";
    document.getElementById("descricao").value = "";
}

mostrarAnimais();