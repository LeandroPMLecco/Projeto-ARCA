
const formulario = document.querySelector(".login-form");

if (formulario) {

    formulario.addEventListener("submit", function (event) {
        event.preventDefault();

        let email = document.getElementById("email").value;
        let senha = document.getElementById("senha").value;

        if (email === "tutor1@gmail.com" && senha === "123456") {
            window.location.href = "tutor1.html";
        }
        else if (email === "adm@gmail.com" && senha === "pref@456") {
            window.location.href = "adm1.html";
        }
        else if (email === "ong@gmail.com" && senha === "ong$-135") {
            window.location.href = "ong1.html";
        }
        else if (email === "denunciante@gmail.com" && senha === "denunciante123") {
            window.location.href = "denunciante1.html";
        }
        else if (email === "adotante@gmail.com" && senha === "adotante123") {
            window.location.href = "adotante1.html";
        }
        else {
            alert("Email ou senha inválidos");
        }
    });

}





document.addEventListener("DOMContentLoaded", function () {
    const anonimo = document.getElementById("anonimo");
    const dados = document.getElementById("dados-opcionais");

    if (anonimo && dados) {

        anonimo.addEventListener("change", function () {
            dados.style.display = anonimo.checked ? "none" : "block";
        });

    }
});





function abrirSidebar() {
    document.getElementById("sidebar").classList.add("aberta");
    document.getElementById("overlay").classList.add("visivel");
}

function fecharSidebar() {
    document.getElementById("sidebar").classList.remove("aberta");
    document.getElementById("overlay").classList.remove("visivel");
}

