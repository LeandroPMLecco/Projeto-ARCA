-- ============================================================
-- PROJETO ARCA — DDL
-- Banco de Dados | Sistemas de Informação / Ciência da Computação / Engenharia de Software
-- Prefeitura da Serra - ES
-- ============================================================

-- CRIAÇÃO PRÉVIA DE TIPOS ENUM
CREATE TYPE status_cadastro_enum    AS ENUM ('Pendente', 'Aprovado', 'Rejeitado', 'Bloqueado');
CREATE TYPE status_validacao_enum   AS ENUM ('Pendente', 'Aprovado', 'Recusado');
CREATE TYPE tipo_documento_enum     AS ENUM ('Comprovante de Residencia', 'Documento Pessoal', 'Laudo Veterinario', 'Foto do Animal', 'Outro');
CREATE TYPE status_adocao_enum      AS ENUM ('Interesse Manifestado', 'Em Analise', 'Aprovado', 'Recusado', 'Cancelado');
CREATE TYPE status_castracao_enum   AS ENUM ('Pendente', 'Aprovado', 'Concluido', 'Cancelado');
CREATE TYPE status_resgate_enum     AS ENUM ('Pendente', 'Em Atendimento', 'Concluido', 'Cancelado');
CREATE TYPE gravidade_enum          AS ENUM ('Leve', 'Moderada', 'Grave', 'Critica');
CREATE TYPE tipo_relatorio_enum     AS ENUM ('Adocao', 'Castracao', 'Resgate', 'Denuncia');
CREATE TYPE sexo_enum               AS ENUM ('M', 'F', 'NI');
CREATE TYPE porte_enum              AS ENUM ('Pequeno', 'Medio', 'Grande');
CREATE TYPE status_pet_enum         AS ENUM ('Disponivel', 'Em processo de adocao', 'Adotado');

-- ============================================================
-- ENTIDADES INDEPENDENTES
-- ============================================================

CREATE TABLE ADMINISTRADOR (
    id     SERIAL        PRIMARY KEY,
    login  VARCHAR(100)  NOT NULL UNIQUE,
    senha  VARCHAR(255)  NOT NULL,
    nome   VARCHAR(100)  NOT NULL
);

CREATE TABLE ENDERECO (
    id      SERIAL       PRIMARY KEY,
    rua     VARCHAR(100) NOT NULL,
    numero  VARCHAR(10)  NOT NULL,
    bairro  VARCHAR(100) NOT NULL,
    cidade  VARCHAR(50)  NOT NULL,
    uf      CHAR(2)      NOT NULL,
    cep     CHAR(8)      NOT NULL
);

-- ============================================================
-- USUÁRIO
-- ============================================================

CREATE TABLE USUARIO (
    id               SERIAL                   PRIMARY KEY,
    cpf              CHAR(11)                 NOT NULL UNIQUE,
    nome             VARCHAR(20)              NOT NULL,
    sobrenome        VARCHAR(50)              NOT NULL,
    email            VARCHAR(150)             NOT NULL UNIQUE,
    senha            VARCHAR(255)             NOT NULL,
    status_cadastro  status_cadastro_enum     NOT NULL DEFAULT 'Pendente',
    nis              CHAR(11)                 NULL,
    ddd              CHAR(2)                  NOT NULL,
    telefone         VARCHAR(9)               NOT NULL
);

-- Endereço vinculado ao usuário (1:N)
ALTER TABLE ENDERECO
    ADD COLUMN id_usuario INT NULL,
    ADD CONSTRAINT fk_endereco_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES USUARIO(id)
        ON DELETE CASCADE;

-- ============================================================
-- DOCUMENTO
-- ============================================================

CREATE TABLE DOCUMENTO (
    id                SERIAL                   PRIMARY KEY,
    tipo              tipo_documento_enum       NOT NULL,
    arquivo           VARCHAR(500)             NOT NULL,
    data_upload       DATE                     NOT NULL DEFAULT CURRENT_DATE,
    status_validacao  status_validacao_enum    NOT NULL DEFAULT 'Pendente',
    id_usuario        INT                      NOT NULL,
    CONSTRAINT fk_documento_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES USUARIO(id)
        ON DELETE CASCADE
);

-- ============================================================
-- APROVAÇÃO (Administrador aprova Usuário)
-- ============================================================

CREATE TABLE APROVACAO (
    id                SERIAL                   PRIMARY KEY,
    id_usuario        INT                      NOT NULL,
    id_administrador  INT                      NULL,
    status            status_cadastro_enum     NOT NULL DEFAULT 'Pendente',
    data_avaliacao    DATE                     NULL,
    observacao        TEXT                     NULL,
    CONSTRAINT fk_aprovacao_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES USUARIO(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_aprovacao_administrador
        FOREIGN KEY (id_administrador)
        REFERENCES ADMINISTRADOR(id)
        ON DELETE RESTRICT
);

-- ============================================================
-- ESPECIALIZAÇÃO DE USUÁRIO — Total e Sobreposta (t, c)
-- Adotante, Tutor e Protetor
-- ============================================================

CREATE TABLE ADOTANTE (
    id_usuario INT PRIMARY KEY,
    CONSTRAINT fk_adotante_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES USUARIO(id)
        ON DELETE CASCADE
);

CREATE TABLE TUTOR (
    id_usuario INT PRIMARY KEY,
    CONSTRAINT fk_tutor_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES USUARIO(id)
        ON DELETE CASCADE
);

CREATE TABLE PROTETOR (
    id_usuario INT PRIMARY KEY,
    CONSTRAINT fk_protetor_usuario
        FOREIGN KEY (id_usuario)
        REFERENCES USUARIO(id)
        ON DELETE CASCADE
);

-- ============================================================
-- ESPECIALIZAÇÃO DE PROTETOR — Total e Disjunta (t, d)
-- Protetor Independente não possui atributos extras (não gera tabela)
-- ONG possui atributos adicionais
-- ============================================================

CREATE TABLE ONG (
    id_usuario_protetor  INT           PRIMARY KEY,
    cnpj                 VARCHAR(18)   NOT NULL UNIQUE,
    nome_institucional   VARCHAR(100)  NOT NULL,
    CONSTRAINT fk_ong_protetor
        FOREIGN KEY (id_usuario_protetor)
        REFERENCES PROTETOR(id_usuario)
        ON DELETE CASCADE
);

-- ============================================================
-- PET
-- ============================================================

CREATE TABLE PET (
    id                       SERIAL           PRIMARY KEY,
    data_cadastro            DATE             NOT NULL DEFAULT CURRENT_DATE,
    nome                     VARCHAR(50)      NOT NULL,
    especie                  VARCHAR(100)     NOT NULL,
    raca                     VARCHAR(100)     NULL,
    data_nascimento_estimada DATE             NULL,
    sexo                     sexo_enum        NOT NULL,
    porte                    porte_enum       NOT NULL,
    descricao                TEXT             NULL,
    status                   status_pet_enum  NOT NULL DEFAULT 'Disponivel',
    id_protetor              INT              NOT NULL,
    CONSTRAINT fk_pet_protetor
        FOREIGN KEY (id_protetor)
        REFERENCES PROTETOR(id_usuario)
        ON DELETE RESTRICT
);

-- ============================================================
-- SOLICITAÇÃO DE ADOÇÃO (N:N entre Adotante e Pet)
-- ============================================================

CREATE TABLE SOLICITA_ADOCAO (
    num_protocolo        SERIAL                PRIMARY KEY,
    data_manif_interesse DATE                  NOT NULL DEFAULT CURRENT_DATE,
    status               status_adocao_enum    NOT NULL DEFAULT 'Interesse Manifestado',
    id_usuario_adotante  INT                   NOT NULL,
    id_pet               INT                   NOT NULL,
    CONSTRAINT fk_solicita_adocao_adotante
        FOREIGN KEY (id_usuario_adotante)
        REFERENCES ADOTANTE(id_usuario)
        ON DELETE RESTRICT,
    CONSTRAINT fk_solicita_adocao_pet
        FOREIGN KEY (id_pet)
        REFERENCES PET(id)
        ON DELETE RESTRICT
);

-- ============================================================
-- CASTRAÇÃO
-- ============================================================

CREATE TABLE CASTRACAO (
    num_protocolo     SERIAL                  PRIMARY KEY,
    status            status_castracao_enum   NOT NULL DEFAULT 'Pendente',
    data_solicitacao  DATE                    NOT NULL DEFAULT CURRENT_DATE,
    id_usuario_tutor  INT                     NOT NULL,
    id_pet            INT                     NOT NULL,
    CONSTRAINT fk_castracao_tutor
        FOREIGN KEY (id_usuario_tutor)
        REFERENCES TUTOR(id_usuario)
        ON DELETE RESTRICT,
    CONSTRAINT fk_castracao_pet
        FOREIGN KEY (id_pet)
        REFERENCES PET(id)
        ON DELETE RESTRICT
);

-- ============================================================
-- RESGATE
-- id_pet aceita NULL pois o resgate pode envolver animal sem cadastro prévio
-- ============================================================

CREATE TABLE RESGATE (
    id                  SERIAL               PRIMARY KEY,
    id_endereco         INT                  NOT NULL,
    detalhes            TEXT                 NOT NULL,
    gravidade           gravidade_enum       NOT NULL,
    status              status_resgate_enum  NOT NULL DEFAULT 'Pendente',
    id_usuario_protetor INT                  NOT NULL,
    id_pet              INT                  NULL,
    CONSTRAINT fk_resgate_endereco
        FOREIGN KEY (id_endereco)
        REFERENCES ENDERECO(id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_resgate_protetor
        FOREIGN KEY (id_usuario_protetor)
        REFERENCES PROTETOR(id_usuario)
        ON DELETE RESTRICT,
    CONSTRAINT fk_resgate_pet
        FOREIGN KEY (id_pet)
        REFERENCES PET(id)
        ON DELETE SET NULL
);

-- ============================================================
-- DENÚNCIA (anônima — sem vínculo com Usuário)
-- ============================================================

CREATE TABLE DENUNCIA (
    num_protocolo        SERIAL  PRIMARY KEY,
    data_denuncia        DATE    NOT NULL DEFAULT CURRENT_DATE,
    descricao_maus_tratos TEXT   NOT NULL,
    id_endereco          INT     NOT NULL,
    CONSTRAINT fk_denuncia_endereco
        FOREIGN KEY (id_endereco)
        REFERENCES ENDERECO(id)
        ON DELETE RESTRICT
);

-- ============================================================
-- RELATÓRIO
-- ============================================================

CREATE TABLE RELATORIO (
    id               SERIAL               PRIMARY KEY,
    tipo             tipo_relatorio_enum  NOT NULL,
    mes              SMALLINT             NOT NULL CHECK (mes BETWEEN 1 AND 12),
    ano              SMALLINT             NOT NULL CHECK (ano >= 2022),
    abrangencia      VARCHAR(100)         NOT NULL,
    id_administrador INT                  NOT NULL,
    CONSTRAINT fk_relatorio_administrador
        FOREIGN KEY (id_administrador)
        REFERENCES ADMINISTRADOR(id)
        ON DELETE RESTRICT
);
