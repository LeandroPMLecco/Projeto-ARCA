-- ============================================================
-- PROJETO ARCA — DML
-- Inserção de dados para popular o banco (> 50.000 registros)
-- ============================================================

-- ADMINISTRADORES (10 registros)
INSERT INTO ADMINISTRADOR (login, senha, nome)
SELECT
    'admin' || gs,
    md5(random()::text),
    'Administrador ' || gs
FROM generate_series(1, 10) gs;

-- ============================================================
-- USUÁRIOS (25.000 registros)
-- Distribuição: 85% Aprovado, 10% Pendente, 5% Rejeitado
-- ============================================================
INSERT INTO USUARIO (cpf, nome, sobrenome, email, senha, status_cadastro, nis, ddd, telefone)
SELECT
    lpad((10000000000 + gs)::text, 11, '0'),
    (ARRAY['Joao','Maria','Pedro','Ana','Lucas','Carlos','Paulo','Julia',
           'Fernanda','Bruno','Marcos','Gabriel'])[floor(random()*12+1)],
    (ARRAY['Silva','Souza','Oliveira','Santos','Ferreira','Costa',
           'Rodrigues','Almeida','Nascimento'])[floor(random()*9+1)],
    'usuario' || gs || '@arca.com',
    md5(random()::text),
    CASE
        WHEN r < 0.85 THEN 'Aprovado'
        WHEN r < 0.95 THEN 'Pendente'
        ELSE 'Rejeitado'
    END::status_cadastro_enum,
    CASE WHEN random() < 0.30 THEN lpad((20000000000 + gs)::text, 11, '0') ELSE NULL END,
    CASE WHEN random() < 0.95 THEN '27' ELSE '28' END,
    '9' || lpad(floor(random()*100000000)::text, 8, '0')
FROM (SELECT gs, random() AS r FROM generate_series(1, 25000) gs) dados;

-- ============================================================
-- ENDEREÇOS DOS USUÁRIOS (1 por usuário = 25.000 registros)
-- ============================================================
INSERT INTO ENDERECO (rua, numero, bairro, cidade, uf, cep, id_usuario)
SELECT
    'Rua ' || id,
    (floor(random()*9999) + 1)::text,
    CASE
        WHEN r < 0.12 THEN 'Laranjeiras'
        WHEN r < 0.22 THEN 'Feu Rosa'
        WHEN r < 0.31 THEN 'Novo Horizonte'
        WHEN r < 0.39 THEN 'Cidade Continental'
        WHEN r < 0.47 THEN 'Barcelona'
        WHEN r < 0.54 THEN 'Jose de Anchieta'
        WHEN r < 0.60 THEN 'Valparaiso'
        WHEN r < 0.66 THEN 'Jardim Carapina'
        WHEN r < 0.71 THEN 'Serra Sede'
        WHEN r < 0.75 THEN 'Eurico Salles'
        ELSE 'Planalto Serrano'
    END,
    'Serra', 'ES',
    (29160000 + floor(random()*39999))::text,
    id
FROM (SELECT id, random() AS r FROM USUARIO) t;

-- ============================================================
-- DOCUMENTOS
-- Comprovante obrigatório para todos os usuários (25.000)
-- + Documentos extras (25.000)
-- Total: 50.000 registros
-- ============================================================
INSERT INTO DOCUMENTO (tipo, arquivo, data_upload, status_validacao, id_usuario)
SELECT
    'Comprovante de Residencia',
    '/uploads/comprovante_' || id || '.pdf',
    CURRENT_DATE - floor(random()*365)::int,
    CASE WHEN random() < 0.85 THEN 'Aprovado' ELSE 'Pendente' END::status_validacao_enum,
    id
FROM USUARIO;

INSERT INTO DOCUMENTO (tipo, arquivo, data_upload, status_validacao, id_usuario)
SELECT
    CASE
        WHEN random() < 0.50 THEN 'Documento Pessoal'
        WHEN random() < 0.80 THEN 'Foto do Animal'
        WHEN random() < 0.95 THEN 'Laudo Veterinario'
        ELSE 'Outro'
    END::tipo_documento_enum,
    '/uploads/doc_extra_' || gs || '.pdf',
    CURRENT_DATE - floor(random()*720)::int,
    CASE
        WHEN random() < 0.75 THEN 'Aprovado'
        WHEN random() < 0.90 THEN 'Pendente'
        ELSE 'Recusado'
    END::status_validacao_enum,
    floor(random()*25000 + 1)
FROM generate_series(1, 25000) gs;

-- ============================================================
-- ESPECIALIZAÇÕES DE USUÁRIO
-- ============================================================
INSERT INTO ADOTANTE (id_usuario)
SELECT id FROM USUARIO WHERE random() < 0.48;

INSERT INTO TUTOR (id_usuario)
SELECT id FROM USUARIO WHERE random() < 0.60;

INSERT INTO PROTETOR (id_usuario)
SELECT id FROM USUARIO WHERE random() < 0.10;

-- Garantindo especialização total (todo usuário tem ao menos 1 perfil)
INSERT INTO ADOTANTE (id_usuario)
SELECT u.id
FROM USUARIO u
LEFT JOIN ADOTANTE a ON a.id_usuario = u.id
LEFT JOIN TUTOR     t ON t.id_usuario = u.id
LEFT JOIN PROTETOR  p ON p.id_usuario = u.id
WHERE a.id_usuario IS NULL AND t.id_usuario IS NULL AND p.id_usuario IS NULL;

-- ============================================================
-- ONGs (~12% dos protetores)
-- ============================================================
INSERT INTO ONG (id_usuario_protetor, cnpj, nome_institucional)
SELECT
    id_usuario,
    '27' || lpad(row_number() over()::text, 12, '0'),
    'ONG Animal ' || row_number() over()
FROM PROTETOR
WHERE random() < 0.12;

-- ============================================================
-- PETS — cadastrados por ONGs
-- ============================================================
WITH ong_qtd AS (
    SELECT id_usuario_protetor, (25 + floor(random()*46))::int AS qtd
    FROM ONG
)
INSERT INTO PET (data_cadastro, nome, especie, raca, data_nascimento_estimada,
                 sexo, porte, descricao, status, id_protetor)
SELECT
    CURRENT_DATE - floor(random()*1095)::int,
    (ARRAY['Rex','Luna','Thor','Mel','Bob','Amora','Nina','Max',
           'Luke','Pandora','Bidu','Maya','Simba','Fred','Belinha'])[floor(random()*15+1)],
    CASE WHEN random() < 0.70 THEN 'Cachorro' WHEN random() < 0.95 THEN 'Gato' ELSE 'Outro' END,
    CASE
        WHEN random() < 0.30 THEN 'SRD'    WHEN random() < 0.40 THEN 'Labrador'
        WHEN random() < 0.50 THEN 'Pitbull' WHEN random() < 0.60 THEN 'Pinscher'
        WHEN random() < 0.70 THEN 'Pastor Alemao' WHEN random() < 0.80 THEN 'Poodle'
        WHEN random() < 0.90 THEN 'Persa'  ELSE 'Siames'
    END,
    CURRENT_DATE - floor(random()*5475)::int,
    CASE WHEN random() < 0.50 THEN 'M' ELSE 'F' END::sexo_enum,
    CASE WHEN random() < 0.45 THEN 'Pequeno' WHEN random() < 0.80 THEN 'Medio' ELSE 'Grande' END::porte_enum,
    'Animal acolhido por ONG parceira.',
    CASE WHEN random() < 0.75 THEN 'Disponivel'
         WHEN random() < 0.92 THEN 'Em processo de adocao'
         ELSE 'Adotado' END::status_pet_enum,
    oq.id_usuario_protetor
FROM ong_qtd oq
JOIN generate_series(1, oq.qtd) gs ON TRUE;

-- PETS — cadastrados por protetores independentes
WITH independentes_qtd AS (
    SELECT p.id_usuario, (1 + floor(random()*6))::int AS qtd
    FROM PROTETOR p
    LEFT JOIN ONG o ON o.id_usuario_protetor = p.id_usuario
    WHERE o.id_usuario_protetor IS NULL
)
INSERT INTO PET (data_cadastro, nome, especie, raca, data_nascimento_estimada,
                 sexo, porte, descricao, status, id_protetor)
SELECT
    CURRENT_DATE - floor(random()*1095)::int,
    (ARRAY['Rex','Luna','Thor','Mel','Bob','Amora','Nina','Max',
           'Luke','Pandora','Bidu','Maya','Simba','Fred','Belinha'])[floor(random()*15+1)],
    CASE WHEN random() < 0.70 THEN 'Cachorro' WHEN random() < 0.95 THEN 'Gato' ELSE 'Outro' END,
    CASE
        WHEN random() < 0.30 THEN 'SRD'    WHEN random() < 0.40 THEN 'Labrador'
        WHEN random() < 0.50 THEN 'Pitbull' WHEN random() < 0.60 THEN 'Pinscher'
        WHEN random() < 0.70 THEN 'Pastor Alemao' WHEN random() < 0.80 THEN 'Poodle'
        WHEN random() < 0.90 THEN 'Persa'  ELSE 'Siames'
    END,
    CURRENT_DATE - floor(random()*5475)::int,
    CASE WHEN random() < 0.50 THEN 'M' ELSE 'F' END::sexo_enum,
    CASE WHEN random() < 0.45 THEN 'Pequeno' WHEN random() < 0.80 THEN 'Medio' ELSE 'Grande' END::porte_enum,
    'Animal acolhido por protetor independente.',
    CASE WHEN random() < 0.75 THEN 'Disponivel'
         WHEN random() < 0.92 THEN 'Em processo de adocao'
         ELSE 'Adotado' END::status_pet_enum,
    iq.id_usuario
FROM independentes_qtd iq
JOIN generate_series(1, iq.qtd) gs ON TRUE;

-- ============================================================
-- SOLICITAÇÕES DE ADOÇÃO (8.000 registros)
-- ============================================================
WITH pets_sorteados AS (
    SELECT id, row_number() OVER() AS rn
    FROM (SELECT id FROM PET WHERE status = 'Disponivel' ORDER BY random() LIMIT 8000) p
),
adotantes_sorteados AS (
    SELECT id_usuario, row_number() OVER() AS rn
    FROM (SELECT id_usuario FROM ADOTANTE ORDER BY random() LIMIT 8000) a
),
pares AS (
    SELECT p.id AS id_pet, a.id_usuario, random() AS r,
           CURRENT_DATE - floor(random()*365)::int AS data_solic
    FROM pets_sorteados p JOIN adotantes_sorteados a ON p.rn = a.rn
)
INSERT INTO SOLICITA_ADOCAO (data_manif_interesse, status, id_usuario_adotante, id_pet)
SELECT
    data_solic,
    CASE
        WHEN r < 0.40 THEN 'Interesse Manifestado'
        WHEN r < 0.65 THEN 'Em Analise'
        WHEN r < 0.85 THEN 'Aprovado'
        WHEN r < 0.95 THEN 'Recusado'
        ELSE 'Cancelado'
    END::status_adocao_enum,
    id_usuario, id_pet
FROM pares;

-- Atualiza status dos pets conforme adoções
UPDATE PET SET status = 'Disponivel';
UPDATE PET SET status = 'Adotado'
WHERE id IN (SELECT id_pet FROM SOLICITA_ADOCAO WHERE status = 'Aprovado');
UPDATE PET SET status = 'Em processo de adocao'
WHERE id IN (SELECT id_pet FROM SOLICITA_ADOCAO WHERE status IN ('Interesse Manifestado','Em Analise'));

-- ============================================================
-- CASTRAÇÕES (7.000 registros)
-- ============================================================
WITH pets_sorteados AS (
    SELECT id, row_number() OVER() AS rn
    FROM (
        SELECT id FROM PET WHERE status = 'Adotado' ORDER BY random() LIMIT 1548
        UNION ALL
        SELECT id FROM PET WHERE status = 'Em processo de adocao' ORDER BY random() LIMIT 2500
        UNION ALL
        SELECT id FROM PET WHERE status = 'Disponivel' ORDER BY random() LIMIT 2952
    ) p
),
tutores_sorteados AS (
    SELECT id_usuario, row_number() OVER() AS rn
    FROM (SELECT id_usuario FROM TUTOR ORDER BY random() LIMIT 7000) t
),
pares AS (
    SELECT p.id AS id_pet, t.id_usuario, random() AS r,
           CURRENT_DATE - floor(random()*730)::int AS data_sol
    FROM pets_sorteados p JOIN tutores_sorteados t ON p.rn = t.rn
)
INSERT INTO CASTRACAO (status, data_solicitacao, id_usuario_tutor, id_pet)
SELECT
    CASE
        WHEN r < 0.15 THEN 'Pendente'
        WHEN r < 0.35 THEN 'Aprovado'
        WHEN r < 0.95 THEN 'Concluido'
        ELSE 'Cancelado'
    END::status_castracao_enum,
    data_sol, id_usuario, id_pet
FROM pares;

-- ============================================================
-- ENDEREÇOS AVULSOS PARA RESGATES (3.000 registros)
-- ============================================================
INSERT INTO ENDERECO (rua, numero, bairro, cidade, uf, cep, id_usuario)
SELECT
    'Rua do Resgate ' || gs,
    (floor(random()*9999) + 1)::text,
    CASE floor(random()*11)::int
        WHEN 0 THEN 'Laranjeiras'    WHEN 1 THEN 'Feu Rosa'
        WHEN 2 THEN 'Novo Horizonte' WHEN 3 THEN 'Cidade Continental'
        WHEN 4 THEN 'Barcelona'      WHEN 5 THEN 'Jose de Anchieta'
        WHEN 6 THEN 'Valparaiso'     WHEN 7 THEN 'Jardim Carapina'
        WHEN 8 THEN 'Serra Sede'     WHEN 9 THEN 'Eurico Salles'
        ELSE 'Planalto Serrano'
    END,
    'Serra', 'ES',
    (29160000 + floor(random()*39999))::text,
    NULL
FROM generate_series(1, 3000) gs;

-- ============================================================
-- RESGATES (3.000 registros)
-- ============================================================
WITH
enderecos_resgate AS (
    SELECT id, row_number() OVER (ORDER BY id DESC) AS rn
    FROM ENDERECO WHERE id_usuario IS NULL LIMIT 3000
),
protetores AS (
    SELECT id_usuario, row_number() OVER (ORDER BY random()) AS rn
    FROM PROTETOR ORDER BY random() LIMIT 3000
),
pets_para_resgate AS (
    SELECT id AS id_pet, row_number() OVER (ORDER BY random()) AS rn
    FROM PET ORDER BY random() LIMIT 1200
)
INSERT INTO RESGATE (id_endereco, detalhes, gravidade, status, id_usuario_protetor, id_pet)
SELECT
    e.id,
    CASE floor(random()*8)::int
        WHEN 0 THEN 'Animal encontrado ferido na via publica.'
        WHEN 1 THEN 'Animal abandonado em frente a residencia.'
        WHEN 2 THEN 'Animal preso em bueiro ou construcao.'
        WHEN 3 THEN 'Animal desnutrido e debilitado.'
        WHEN 4 THEN 'Animal encontrado apos acidente de transito.'
        WHEN 5 THEN 'Filhotes abandonados sem mae.'
        WHEN 6 THEN 'Animal em situacao de maus-tratos.'
        ELSE 'Animal doente sem tutor identificado.'
    END,
    CASE
        WHEN random() < 0.30 THEN 'Leve'
        WHEN random() < 0.65 THEN 'Moderada'
        WHEN random() < 0.90 THEN 'Grave'
        ELSE 'Critica'
    END::gravidade_enum,
    CASE
        WHEN random() < 0.10 THEN 'Pendente'
        WHEN random() < 0.25 THEN 'Em Atendimento'
        WHEN random() < 0.90 THEN 'Concluido'
        ELSE 'Cancelado'
    END::status_resgate_enum,
    p.id_usuario,
    CASE WHEN pr.id_pet IS NOT NULL AND random() < 0.40 THEN pr.id_pet ELSE NULL END
FROM protetores p
JOIN enderecos_resgate e ON e.rn = p.rn
LEFT JOIN pets_para_resgate pr ON pr.rn = p.rn;

-- ============================================================
-- DENÚNCIAS (4.000 registros)
-- ============================================================
WITH enderecos_sorteados AS (
    SELECT id, row_number() OVER() AS rn
    FROM (SELECT id FROM ENDERECO ORDER BY random() LIMIT 4000) e
)
INSERT INTO DENUNCIA (data_denuncia, descricao_maus_tratos, id_endereco)
SELECT
    CURRENT_DATE - floor(random()*730)::int,
    CASE floor(random()*8 + 1)::int
        WHEN 1 THEN 'Animal mantido sem alimentacao adequada.'
        WHEN 2 THEN 'Animal mantido em espaco inadequado.'
        WHEN 3 THEN 'Suspeita de abandono de animal.'
        WHEN 4 THEN 'Animal apresentando sinais de maus-tratos.'
        WHEN 5 THEN 'Animal sem acesso regular a agua.'
        WHEN 6 THEN 'Animal exposto ao sol e chuva continuamente.'
        WHEN 7 THEN 'Denuncia de agressao fisica ao animal.'
        ELSE 'Condicoes inadequadas de higiene.'
    END,
    id
FROM enderecos_sorteados;

-- ============================================================
-- APROVAÇÕES (todos os usuários — 25.000 registros)
-- ============================================================
INSERT INTO APROVACAO (id_usuario, id_administrador, status, observacao, data_avaliacao)
SELECT
    u.id,
    CASE WHEN u.status_cadastro = 'Pendente' THEN NULL ELSE (floor(random()*10) + 1)::int END,
    u.status_cadastro,
    CASE u.status_cadastro
        WHEN 'Rejeitado' THEN
            CASE floor(random()*4)::int
                WHEN 0 THEN 'Comprovante de residencia ilegivel ou invalido.'
                WHEN 1 THEN 'Documento pessoal com dados divergentes do cadastro.'
                WHEN 2 THEN 'Foto do animal nao corresponde ao descrito.'
                ELSE 'Documentacao incompleta. Reenvio necessario.'
            END
        WHEN 'Bloqueado' THEN
            CASE floor(random()*3)::int
                WHEN 0 THEN 'Endereco fora da area de abrangencia do projeto (Serra - ES).'
                WHEN 1 THEN 'Perfil incompativel com os criterios do Projeto Arca.'
                ELSE 'Suspeita de cadastro duplicado ou identidade invalida.'
            END
        ELSE NULL
    END,
    CASE WHEN u.status_cadastro = 'Pendente' THEN NULL
         ELSE CURRENT_DATE - floor(random()*365)::int END
FROM USUARIO u;

-- ============================================================
-- RELATÓRIOS (240 registros — 4 tipos × 12 meses × 2 anos × 10 admins)
-- ============================================================
INSERT INTO RELATORIO (tipo, mes, ano, abrangencia, id_administrador)
SELECT
    tipo::tipo_relatorio_enum, mes, ano,
    CASE floor(random()*3)::int
        WHEN 0 THEN 'Serra - ES'
        WHEN 1 THEN 'Grande Vitoria - ES'
        ELSE 'Espirito Santo'
    END,
    id_administrador
FROM (
    SELECT
        unnest(ARRAY['Adocao','Castracao','Resgate','Denuncia']) AS tipo,
        mes, ano,
        ((gs - 1) % 10 + 1) AS id_administrador
    FROM generate_series(1, 60) gs
    CROSS JOIN LATERAL (
        SELECT
            (ARRAY[1,2,3,4,5,6,7,8,9,10,11,12])[((gs - 1) % 12) + 1] AS mes,
            CASE WHEN gs <= 30 THEN 2023 ELSE 2024 END AS ano
    ) datas
) combinacoes;

-- ============================================================
-- VERIFICAÇÃO DO TOTAL DE REGISTROS
-- ============================================================
SELECT relname AS tabela, n_live_tup AS registros
FROM pg_stat_user_tables
WHERE schemaname = 'public'
UNION ALL
SELECT 'TOTAL', SUM(n_live_tup)
FROM pg_stat_user_tables
WHERE schemaname = 'public'
ORDER BY registros DESC;
