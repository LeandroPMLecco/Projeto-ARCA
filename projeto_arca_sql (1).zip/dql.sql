-- ============================================================
-- PROJETO ARCA — DQL
-- Relatório Analítico: Adoções, Castrações e Médias Mensais
-- ============================================================


-- ============================================================
-- QUERY 1 — Adoções de cães e gatos por mês
-- Exibe o total de adoções aprovadas por espécie (Cachorro/Gato)
-- agrupadas por ano e mês, ordenadas cronologicamente.
-- ============================================================

SELECT
    TO_CHAR(sa.data_manif_interesse, 'YYYY-MM')  AS ano_mes,
    EXTRACT(YEAR  FROM sa.data_manif_interesse)::int AS ano,
    EXTRACT(MONTH FROM sa.data_manif_interesse)::int AS mes,
    TO_CHAR(sa.data_manif_interesse, 'TMMonth')  AS nome_mes,
    p.especie,
    COUNT(*)                                      AS total_adocoes
FROM SOLICITA_ADOCAO sa
JOIN PET p ON p.id = sa.id_pet
WHERE
    sa.status   = 'Aprovado'
    AND p.especie IN ('Cachorro', 'Gato')
GROUP BY
    TO_CHAR(sa.data_manif_interesse, 'YYYY-MM'),
    EXTRACT(YEAR  FROM sa.data_manif_interesse),
    EXTRACT(MONTH FROM sa.data_manif_interesse),
    TO_CHAR(sa.data_manif_interesse, 'TMMonth'),
    p.especie
ORDER BY
    ano_mes,
    p.especie;


-- ============================================================
-- QUERY 2 — Demanda de castração de cães e gatos
-- Exibe o total de solicitações de castração por espécie
-- agrupadas por ano, mês e status do pedido.
-- Permite visualizar o volume de demanda e o andamento dos casos.
-- ============================================================

SELECT
    TO_CHAR(c.data_solicitacao, 'YYYY-MM')  AS ano_mes,
    EXTRACT(YEAR  FROM c.data_solicitacao)::int AS ano,
    EXTRACT(MONTH FROM c.data_solicitacao)::int AS mes,
    TO_CHAR(c.data_solicitacao, 'TMMonth')  AS nome_mes,
    p.especie,
    c.status,
    COUNT(*)                                 AS total_solicitacoes
FROM CASTRACAO c
JOIN PET p ON p.id = c.id_pet
WHERE
    p.especie IN ('Cachorro', 'Gato')
GROUP BY
    TO_CHAR(c.data_solicitacao, 'YYYY-MM'),
    EXTRACT(YEAR  FROM c.data_solicitacao),
    EXTRACT(MONTH FROM c.data_solicitacao),
    TO_CHAR(c.data_solicitacao, 'TMMonth'),
    p.especie,
    c.status
ORDER BY
    ano_mes,
    p.especie,
    c.status;


-- ============================================================
-- QUERY 3 — Média mensal de adoções por espécie
-- Calcula a média de adoções aprovadas por mês em cada ano,
-- separando cães e gatos.
-- Útil para identificar sazonalidade e tendências de adoção.
-- ============================================================

WITH adocoes_por_mes AS (
    SELECT
        EXTRACT(YEAR  FROM sa.data_manif_interesse)::int AS ano,
        EXTRACT(MONTH FROM sa.data_manif_interesse)::int AS mes,
        p.especie,
        COUNT(*) AS total_adocoes
    FROM SOLICITA_ADOCAO sa
    JOIN PET p ON p.id = sa.id_pet
    WHERE
        sa.status   = 'Aprovado'
        AND p.especie IN ('Cachorro', 'Gato')
    GROUP BY
        EXTRACT(YEAR  FROM sa.data_manif_interesse),
        EXTRACT(MONTH FROM sa.data_manif_interesse),
        p.especie
)
SELECT
    ano,
    especie,
    ROUND(AVG(total_adocoes), 2)  AS media_mensal_adocoes,
    SUM(total_adocoes)            AS total_anual,
    MAX(total_adocoes)            AS maior_mes,
    MIN(total_adocoes)            AS menor_mes,
    COUNT(*)                      AS meses_com_adocao
FROM adocoes_por_mes
GROUP BY
    ano,
    especie
ORDER BY
    ano,
    especie;
